import pygame
import random

pygame.init()

# Screen dimensions
screen_width, screen_height = 1235, 798
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Space Game')

# Add the image file
bg = pygame.image.load(r"C:\Users\praha\Downloads\BG.jpg")

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

# Load spaceship image
spaceship_img = pygame.image.load(r"C:\Users\praha\Downloads\WRocket.jpg")
spaceship_img = pygame.transform.scale(spaceship_img, (124, 124))


# Load alien image
alien_img = pygame.image.load(r"C:\Users\praha\Downloads\Orange.PNG")
alien_img = pygame.transform.scale(alien_img, (50, 50))
alien_img = pygame.image.load(r"C:\Users\praha\Downloads\Blue.PNG")
alien_img = pygame.transform.scale(alien_img, (50, 50))
alien_img = pygame.image.load(r"C:\Users\praha\Downloads\Green.PNG")
alien_img = pygame.transform.scale(alien_img, (50, 50))

# Bullet image
bullet_img = pygame.Surface((8, 20))
bullet_img.fill(RED)

# Spaceship class
class Spaceship(pygame.sprite.Sprite):
    def __init__(self, player_id):
        super().__init__()
        self.image = spaceship_img
        self.rect = self.image.get_rect(center=(screen_width // 2, screen_height - 50))
        self.speed = 8
        self.bullets = pygame.sprite.Group()
        self.player_id = player_id

    def update(self):
        keys = pygame.key.get_pressed()
        if self.player_id == 1:
            if keys[pygame.K_a]:
                self.rect.x -= self.speed
            if keys[pygame.K_d]:
                self.rect.x += self.speed
            if keys[pygame.K_SPACE]:
                self.shoot()
        if self.player_id == 2:
            if keys[pygame.K_LEFT]:
                self.rect.x -= self.speed
            if keys[pygame.K_RIGHT]:
                self.rect.x += self.speed
            if keys[pygame.K_RETURN]:
                self.shoot()
        if self.player_id == 1:
                if keys[pygame.K_w]:
                    self.rect.y -= self.speed
                if keys[pygame.K_s]:
                    self.rect.y += self.speed
                if keys[pygame.K_SPACE]:
                    self.shoot()
        if self.player_id == 2:
                if keys[pygame.K_UP]:
                    self.rect.y -= self.speed
                if keys[pygame.K_DOWN]:
                    self.rect.y += self.speed
           
        # Ensure the spaceship stays within the screen boundaries
        self.rect.x = max(0, min(self.rect.x, screen_width - self.rect.width))

    def shoot(self):
        bullet = Bullet(self.rect.centerx, self.rect.top)
        self.bullets.add(bullet)

# Alien class
class Alien(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.color = random.choice([GREEN, BLUE, YELLOW])
        self.image = alien_img
        self.image.fill(self.color)
        self.rect = self.image.get_rect(center=(random.randint(50, screen_width - 50), 0))
        self.speed = random.randint(2, 5)

    def update(self):
        self.rect.y += self.speed
        if self.rect.top >= screen_height:
            self.rect.y = 0
            self.rect.centerx = random.randint(50, screen_width - 50)

# Bullet class
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = bullet_img
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 10

    def update(self):
        self.rect.y -= self.speed
        if self.rect.bottom <= 0:
            self.kill()

# Create sprite groups
all_sprites = pygame.sprite.Group()
aliens = pygame.sprite.Group()
level = 1

# Create the player spaceships
spaceship1 = Spaceship(player_id=1)
spaceship2 = Spaceship(player_id=2)
spaceship2.rect.y = screen_height - 150  # Position the second spaceship below the first one
all_sprites.add(spaceship1, spaceship2)

# Game states
INTRO = 0
PLAYING = 1
GAME_OVER = 2
game_state = INTRO

# Game loop
clock = pygame.time.Clock()
game_over = False
players_alive = 2

while not game_over:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True
        elif event.type == pygame.KEYDOWN:
            if game_state == INTRO:
                if event.key == pygame.K_SPACE:
                    game_state = PLAYING
            elif game_state == PLAYING:
                if event.key == pygame.K_SPACE:
                    spaceship1.shoot()
                    spaceship2.shoot()
            elif game_state == GAME_OVER:
                if players_alive == 0 and event.key == pygame.K_SPACE:
                    # Reset the game for the next level
                    game_state = PLAYING
                    aliens.empty()
                    all_sprites.empty()
                    spaceship1 = Spaceship(player_id=1)
                    spaceship2 = Spaceship(player_id=2)
                    spaceship2.rect.y = screen_height - 150
                    all_sprites.add(spaceship1, spaceship2)
                    level = 1
                    players_alive = 2

    if game_state == PLAYING:
        # Spawn aliens
        max_aliens_per_level = 20
        if len(aliens) < max_aliens_per_level * level:
            alien = Alien()
            all_sprites.add(alien)
            aliens.add(alien)

        # Update sprites
        all_sprites.update()

        # Check for collisions
        for alien in aliens:
            if pygame.sprite.spritecollide(alien, spaceship1.bullets, True):
                alien.kill()
            if pygame.sprite.spritecollide(alien, spaceship2.bullets, True):
                alien.kill()

            if alien.rect.colliderect(spaceship2.rect):
# Player 2 loses when an alien reaches their spaceship
                players_alive -= 1
            if players_alive == 1:  # Check if only Player 1 is alive
                game_state = GAME_OVER
# Draw everything
    screen.fill(WHITE)

    bg = pygame.transform.scale(bg, (1235, 798))
    screen.blit(bg, (0,0))

    if game_state == INTRO:
        # Display the intro screen
        font = pygame.font.Font(None, 36)
        text = font.render("Press SPACE to start", True, RED)
        text_rect = text.get_rect(center=(screen_width // 2, screen_height // 2))
        screen.blit(text, text_rect)
    elif game_state == PLAYING:
        # Draw spaceships, aliens, and bullets during gameplay
        all_sprites.draw(screen)


    
    
    pygame.display.flip()

    # Control the frame rate
    clock.tick(60)

pygame.quit()